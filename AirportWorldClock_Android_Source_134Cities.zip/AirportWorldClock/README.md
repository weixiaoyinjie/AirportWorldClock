# 全球机场时间 · Airport World Clock

一个不依赖第三方 UI/网络库的轻量原生 Android 世界时钟，面向国际机场所在城市。

## 功能

- 134 座机场城市，支持机场三字代码（IATA）、城市中文名、英文名搜索；同城多个机场共用一个城市时钟。
- 默认收藏布宜诺斯艾利斯、纽约、伦敦、巴黎、迪拜、多哈、新加坡、香港、北京、上海、东京、悉尼；可自由增减。
- 选择参考城市，逐个展示 `UTC±HH:MM`、相对参考城市的时差、当地日期、星期、昨天/明天标志、昼夜；点击城市查看秒数及夏令时。
- 12/24 小时切换；纯黑 AMOLED 界面；Fold 等宽屏采用双列布局。
- Android `java.time` + IANA ZoneId 计算时区、夏令时，离线可显示；每分钟前台更新一次；退到后台停止刷新。
- 每次打开应用仅请求一次 HTTPS 时间 API（`https://gateway.timeapi.world/timezone/Etc/UTC`），手动点击「校时」可重试。校准仅修正应用内部时钟，不修改手机系统时间。失败时回退设备时钟；网络服务是第三方服务，受其可用性/配额约束。
- 无广告、无定位权限、无第三方 SDK、无后台常驻服务；唯一网络权限是 INTERNET。

## GitHub Actions 生成 APK

1. 打开 https://github.com/new ，创建一个空仓库（建议私有）。
2. 解压本工程 ZIP，将 ZIP 内所有文件**包括 `.github/workflows/build-apk.yml`** 上传到仓库根目录并提交。可直接在浏览器里将文件夹整个拖入 `Add file → Upload files`，注意确保 `.github` 隐藏文件夹没有漏掉。
3. 打开仓库的 `Actions` → `构建世界机场时间 APK` → `Run workflow`。或者直接 push 到 `main` / `master` 分支自动编译。
4. 在工作流结果页的 `Artifacts` 下载 `AirportWorldClock-debug-APK`，解压获得 `app-debug.apk`，安装到 Android 手机。

当前源码面向 Android 8.0（API 26）及以上，`compileSdk=35`，`targetSdk=35`，AGP 8.9.2 + Gradle 8.11.1 + JDK 17。GitHub Actions 会安装 Android SDK 35。Debug APK 采用 Android 自动生成的调试签名，正常用于自己的设备安装，不适合正式上架应用商店。

## 修改城市

编辑 `app/src/main/java/com/airportworldclock/AirportData.java`：

```
add(a,"JFK","纽约","New York","美国","JFK / EWR / LGA","America/New_York","美洲");
```

参数依次为：主机场代码、中文名、英文名、国家或地区、可搜索的机场代码列表、IANA 时区、分组。**必须使用城市的 IANA 地理时区，不要填写固定的 UTC+N**，否则夏令时会出错。

默认收藏列表在 `DEFAULT_PINS` 常量中更改；网络时间 API URL 在 `MainActivity.SERVER` 中更改。

## 限制

- 应用展示的是各城市的当前时间，并非航班时刻表、航班状态或机场实时营业情况。
- 时间准确性受设备时区数据库是否及时更新影响；网络对时能修正当前 UTC 时间，但**不能自动更新 Android 内置的 IANA 时区规则**。
- 网络校时按请求发送与接收时间的中点估算延时，不保证高精度授时；普通世界时钟的分钟级显示不受影响。
- 工程内没有 Gradle Wrapper，由 GitHub Actions 的 `setup-gradle` 提供指定版本 Gradle。
