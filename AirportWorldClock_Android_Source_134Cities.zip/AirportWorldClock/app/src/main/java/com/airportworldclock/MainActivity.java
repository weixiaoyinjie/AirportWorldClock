package com.airportworldclock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Battery-minded world clock: zero ongoing background services, no dependencies,
 * no location permission. Repaints visible clocks on minute boundaries only.
 */
public final class MainActivity extends Activity {
    private static final int BLACK = Color.rgb(0, 0, 0);
    private static final int CARD = Color.rgb(17, 18, 22);
    private static final int BORDER = Color.rgb(40, 44, 49);
    private static final int WHITE = Color.rgb(245, 250, 250);
    private static final int MUTED = Color.rgb(166, 174, 184);
    private static final int SOFT = Color.rgb(112, 121, 133);
    private static final int MINT = Color.rgb(105, 221, 201);
    private static final int SELECTED = Color.rgb(20, 41, 39);
    private static final String PREFS = "airport_world_clock_v1";
    private static final String SERVER = "https://gateway.timeapi.world/timezone/Etc/UTC";
    private static final String[] WEEK = {"周一", "周二", "周三", "周四", "周五", "周六", "周日"};

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> pinned = new ArrayList<>();
    private final ArrayList<ClockCard> visibleCards = new ArrayList<>();

    private SharedPreferences preferences;
    private String referenceCode = "EZE";
    private boolean showPinned = true;
    private boolean is24Hour = true;
    private boolean syncing = false;
    private boolean hasSynced = false;
    private boolean foreground = false;
    private long calibratedEpochAtAnchor;
    private long calibratedElapsedAnchor;

    private LinearLayout listContainer;
    private TextView referenceText;
    private TextView statusText;
    private TextView summaryText;
    private TextView pinnedTab;
    private TextView allTab;
    private TextView timeFormatButton;
    private TextView syncButton;
    private EditText searchInput;
    private ScrollView scrollView;

    private final Runnable clockTicker = new Runnable() {
        @Override public void run() {
            updateClocks();
            // Once per minute while foregrounded; seconds never repaint every row.
            long now = nowEpochMillis();
            long delay = 60_000L - Math.floorMod(now, 60_000L) + 60L;
            handler.postDelayed(this, Math.max(1_000L, delay));
        }
    };

    private static final class ClockCard {
        AirportCity city;
        TextView time;
        TextView date;
        TextView details;
        ClockCard(AirportCity c, TextView t, TextView d, TextView x) {
            city = c; time = t; date = d; details = x;
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        restoreSettings();
        createInterface();
        renderList();
        synchronizeTime(); // One optional HTTPS request per activity creation; no polling.
    }

    @Override protected void onResume() {
        super.onResume();
        foreground = true;
        handler.removeCallbacks(clockTicker);
        handler.post(clockTicker);
    }

    @Override protected void onPause() {
        foreground = false;
        handler.removeCallbacks(clockTicker);
        super.onPause();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(clockTicker);
        super.onDestroy();
    }

    private void restoreSettings() {
        String csv = preferences.getString("pins", AirportData.DEFAULT_PINS);
        for (String code : csv.split(",")) {
            String value = code.trim();
            if (AirportData.BY_CODE.containsKey(value) && !pinned.contains(value)) pinned.add(value);
        }
        referenceCode = preferences.getString("reference", "EZE");
        if (!AirportData.BY_CODE.containsKey(referenceCode)) referenceCode = "EZE";
        is24Hour = preferences.getBoolean("24h", true);
    }

    private void storeSettings() {
        preferences.edit()
            .putString("pins", android.text.TextUtils.join(",", pinned))
            .putString("reference", referenceCode)
            .putBoolean("24h", is24Hour)
            .apply();
    }

    private void createInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BLACK);
        root.setPadding(dp(16), dp(10), dp(16), dp(12));
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                root.setPadding(dp(16) + bars.left, dp(10) + bars.top,
                        dp(16) + bars.right, dp(12) + bars.bottom);
                return insets;
            });
        }
        setContentView(root);

        LinearLayout top = horizontal(Gravity.CENTER_VERTICAL);
        root.addView(top, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout brand = vertical();
        top.addView(brand, weighted());
        TextView title = label("全球机场时间", 25, WHITE, true);
        brand.addView(title);
        TextView subtitle = label("AIRPORT WORLD CLOCK", 10, MINT, true);
        subtitle.setLetterSpacing(0.13f);
        addWithTop(brand, subtitle, 3);

        timeFormatButton = pill(is24Hour ? "24H" : "12H", false);
        timeFormatButton.setContentDescription("切换十二小时制或二十四小时制");
        timeFormatButton.setOnClickListener(v -> {
            is24Hour = !is24Hour;
            timeFormatButton.setText(is24Hour ? "24H" : "12H");
            storeSettings();
            updateClocks();
        });
        LinearLayout.LayoutParams smallButton = lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38));
        smallButton.rightMargin = dp(7);
        top.addView(timeFormatButton, smallButton);

        syncButton = pill("↻ 校时", false);
        syncButton.setContentDescription("向网络时间 API 进行一次校准");
        syncButton.setOnClickListener(v -> synchronizeTime());
        top.addView(syncButton, lp(ViewGroup.LayoutParams.WRAP_CONTENT, dp(38)));

        LinearLayout referencePanel = vertical();
        referencePanel.setPadding(dp(15), dp(11), dp(15), dp(11));
        referencePanel.setBackground(roundBg(SELECTED, Color.rgb(34, 70, 65), 15));
        LinearLayout.LayoutParams referenceLp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        referenceLp.topMargin = dp(20);
        root.addView(referencePanel, referenceLp);

        TextView refCaption = label("参考城市  ·  点击切换", 10, MINT, false);
        referencePanel.addView(refCaption);
        referenceText = label("布宜诺斯艾利斯  --:--", 18, WHITE, true);
        addWithTop(referencePanel, referenceText, 4);
        referencePanel.setOnClickListener(v -> showReferencePicker());
        referencePanel.setContentDescription("更改参考城市");

        LinearLayout tabs = horizontal(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams tabsLp = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
        tabsLp.topMargin = dp(15);
        root.addView(tabs, tabsLp);
        pinnedTab = label("★ 常用城市", 14, WHITE, true);
        allTab = label("全部机场城市", 14, WHITE, true);
        pinnedTab.setGravity(Gravity.CENTER);
        allTab.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tabA = weighted();
        tabA.height = dp(42);
        tabA.rightMargin = dp(5);
        tabs.addView(pinnedTab, tabA);
        LinearLayout.LayoutParams tabB = weighted();
        tabB.height = dp(42);
        tabB.leftMargin = dp(5);
        tabs.addView(allTab, tabB);
        pinnedTab.setOnClickListener(v -> {
            showPinned = true;
            searchInput.setText("");
            scrollView.scrollTo(0, 0);
            renderList();
        });
        allTab.setOnClickListener(v -> {
            showPinned = false;
            searchInput.setText("");
            scrollView.scrollTo(0, 0);
            renderList();
        });
        updateTabs();

        LinearLayout searchBar = horizontal(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(dp(12), 0, dp(9), 0);
        searchBar.setBackground(roundBg(CARD, BORDER, 13));
        LinearLayout.LayoutParams searchLp = lp(ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        searchLp.topMargin = dp(12);
        root.addView(searchBar, searchLp);
        TextView magnify = label("⌕", 24, MUTED, false);
        searchBar.addView(magnify, lp(dp(26), ViewGroup.LayoutParams.MATCH_PARENT));
        magnify.setGravity(Gravity.CENTER_VERTICAL);
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(14);
        searchInput.setTextColor(WHITE);
        searchInput.setHintTextColor(SOFT);
        searchInput.setHint("搜索城市或机场代码，如 JFK / PVG");
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setPadding(dp(6), 0, dp(6), 0);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        searchBar.addView(searchInput, weighted());
        TextView clear = label("×", 23, MUTED, false);
        clear.setGravity(Gravity.CENTER);
        clear.setContentDescription("清除搜索内容");
        searchBar.addView(clear, lp(dp(34), ViewGroup.LayoutParams.MATCH_PARENT));
        clear.setOnClickListener(v -> searchInput.setText(""));
        clear.setVisibility(View.GONE);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                clear.setVisibility(s.length() == 0 ? View.GONE : View.VISIBLE);
                renderList();
                if (scrollView != null) scrollView.scrollTo(0, 0);
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        summaryText = label("", 11, MUTED, false);
        LinearLayout.LayoutParams summaryLp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        summaryLp.topMargin = dp(10);
        summaryLp.bottomMargin = dp(7);
        root.addView(summaryText, summaryLp);

        scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setClipToPadding(false);
        root.addView(scrollView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        listContainer = vertical();
        listContainer.setPadding(0, 0, 0, dp(10));
        scrollView.addView(listContainer, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        statusText = label("时间来源：设备时钟 · 正在尝试联网校准", 10, SOFT, false);
        statusText.setGravity(Gravity.CENTER);
        statusText.setOnClickListener(v -> synchronizeTime());
        LinearLayout.LayoutParams statusLp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(7);
        root.addView(statusText, statusLp);
    }

    private void updateTabs() {
        pinnedTab.setTextColor(showPinned ? MINT : MUTED);
        allTab.setTextColor(showPinned ? MUTED : MINT);
        pinnedTab.setBackground(roundBg(showPinned ? SELECTED : CARD, showPinned ? MINT : BORDER, 12));
        allTab.setBackground(roundBg(showPinned ? CARD : SELECTED, showPinned ? BORDER : MINT, 12));
    }

    private void renderList() {
        if (listContainer == null || searchInput == null) return;
        updateTabs();
        visibleCards.clear();
        listContainer.removeAllViews();
        String query = searchInput.getText().toString().trim();
        ArrayList<AirportCity> showing = new ArrayList<>();
        if (!query.isEmpty()) {
            for (AirportCity city : AirportData.ALL) if (city.matches(query)) showing.add(city);
            addSection("搜索结果", showing);
            summaryText.setText("搜索全部城市 · 找到 " + showing.size() + " 个结果");
        } else if (showPinned) {
            for (String code : pinned) {
                AirportCity found = AirportData.BY_CODE.get(code);
                if (found != null) showing.add(found);
            }
            addSection("常用城市", showing);
            summaryText.setText("已收藏 " + pinned.size() + " 个城市  ·  共收录 " + AirportData.ALL.size() + " 个城市");
        } else {
            for (String region : AirportData.REGIONS) {
                showing.clear();
                for (AirportCity city : AirportData.ALL) if (region.equals(city.region)) showing.add(city);
                addSection(region, showing);
            }
            summaryText.setText("已收录 " + AirportData.ALL.size() + " 个国际机场城市  ·  六大区域");
        }
        if (visibleCards.isEmpty()) {
            TextView empty = label(query.isEmpty() ? "还没有收藏城市。请打开“全部机场城市”，点击 ☆ 添加。" :
                    "没有找到机场城市，请尝试机场代码、中文或英文名。", 14, MUTED, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(22), dp(45), dp(22), dp(45));
            listContainer.addView(empty);
        }
        updateClocks();
    }

    private void addSection(String title, List<AirportCity> cities) {
        if (cities.isEmpty()) return;
        TextView heading = label(title + "  ·  " + cities.size(), 13, MINT, true);
        LinearLayout.LayoutParams hlp = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(13);
        hlp.bottomMargin = dp(10);
        listContainer.addView(heading, hlp);
        boolean twoColumns = getResources().getConfiguration().screenWidthDp >= 620;
        int columns = twoColumns ? 2 : 1;
        for (int index = 0; index < cities.size(); index += columns) {
            LinearLayout row = horizontal(Gravity.TOP);
            listContainer.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            for (int j = 0; j < columns; j++) {
                if (index + j >= cities.size()) {
                    row.addView(new Space(this), weighted());
                } else {
                    AirportCity city = cities.get(index + j);
                    View card = buildCard(city);
                    LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                    cp.bottomMargin = dp(10);
                    if (columns == 2 && j == 0) cp.rightMargin = dp(5);
                    if (columns == 2 && j == 1) cp.leftMargin = dp(5);
                    row.addView(card, cp);
                }
            }
        }
    }

    private View buildCard(AirportCity city) {
        boolean reference = city.code.equals(referenceCode);
        LinearLayout box = vertical();
        box.setPadding(dp(13), dp(13), dp(13), dp(12));
        box.setBackground(roundBg(reference ? Color.rgb(19, 31, 31) : CARD,
                                  reference ? Color.rgb(49, 104, 94) : BORDER, 14));
        box.setMinimumHeight(dp(118));
        box.setOnClickListener(v -> showDetail(city));
        box.setOnLongClickListener(v -> {
            setReference(city.code);
            Toast.makeText(this, "已设为参考城市：" + city.chinese, Toast.LENGTH_SHORT).show();
            return true;
        });

        LinearLayout top = horizontal(Gravity.TOP);
        box.addView(top, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout left = vertical();
        top.addView(left, weighted());
        TextView name = label(city.chinese, 17, WHITE, true);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        left.addView(name);
        TextView eng = label(city.english, 11, MUTED, false);
        eng.setSingleLine(true);
        eng.setEllipsize(android.text.TextUtils.TruncateAt.END);
        addWithTop(left, eng, 4);
        TextView airport = label(city.airports, 11, MINT, true);
        airport.setSingleLine(true);
        airport.setEllipsize(android.text.TextUtils.TruncateAt.END);
        addWithTop(left, airport, 4);

        LinearLayout clock = vertical();
        clock.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams clockLp = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clockLp.leftMargin = dp(5);
        top.addView(clock, clockLp);
        TextView time = label("--:--", is24Hour ? 29 : 25, WHITE, true);
        time.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        time.setGravity(Gravity.RIGHT);
        time.setIncludeFontPadding(false);
        time.setFontFeatureSettings("tnum");
        clock.addView(time);
        TextView date = label("--/-- 周--", 10, MUTED, false);
        date.setGravity(Gravity.RIGHT);
        addWithTop(clock, date, 7);

        TextView star = label(pinned.contains(city.code) ? "★" : "☆", 23,
                              pinned.contains(city.code) ? MINT : SOFT, false);
        star.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        star.setContentDescription((pinned.contains(city.code) ? "取消收藏" : "收藏") + city.chinese);
        LinearLayout.LayoutParams starLp = lp(dp(31), dp(40));
        starLp.leftMargin = dp(5);
        top.addView(star, starLp);
        star.setOnClickListener(v -> togglePin(city.code));

        TextView details = label("", 11, MUTED, false);
        details.setSingleLine(false);
        details.setMaxLines(2);
        LinearLayout.LayoutParams bottom = lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bottom.topMargin = dp(9);
        box.addView(details, bottom);
        visibleCards.add(new ClockCard(city, time, date, details));
        return box;
    }

    private void updateClocks() {
        if (referenceText == null) return;
        Instant instant = Instant.ofEpochMilli(nowEpochMillis());
        AirportCity ref = AirportData.BY_CODE.get(referenceCode);
        if (ref == null) ref = AirportData.BY_CODE.get("EZE");
        ZonedDateTime refTime = instant.atZone(ZoneId.of(ref.zoneId));
        referenceText.setText(ref.chinese + "  " + formatTime(refTime) + "  ·  " + ref.code);
        int referenceOffset = refTime.getOffset().getTotalSeconds();
        for (ClockCard c : visibleCards) {
            ZonedDateTime local = instant.atZone(ZoneId.of(c.city.zoneId));
            c.time.setText(formatTime(local));
            c.time.setTextSize(is24Hour ? 29 : 25);
            long dayDiff = ChronoUnit.DAYS.between(refTime.toLocalDate(), local.toLocalDate());
            String dateString = String.format(Locale.ROOT, "%02d/%02d %s", local.getMonthValue(),
                    local.getDayOfMonth(), WEEK[local.getDayOfWeek().getValue() - 1]);
            if (dayDiff == 1) dateString += " · 明天";
            else if (dayDiff == -1) dateString += " · 昨天";
            else if (dayDiff > 1) dateString += " · +" + dayDiff + "天";
            else if (dayDiff < -1) dateString += " · " + dayDiff + "天";
            c.date.setText(dateString);
            String sun = (local.getHour() >= 7 && local.getHour() < 19) ? "☀ 白天" : "☾ 夜间";
            c.details.setText(formatUTC(local.getOffset().getTotalSeconds()) + "   ·   " +
                    relativeOffset(local.getOffset().getTotalSeconds() - referenceOffset) + "   ·   " + sun);
        }
    }

    private String formatTime(ZonedDateTime dt) {
        int hour = dt.getHour();
        if (is24Hour) return String.format(Locale.US, "%02d:%02d", hour, dt.getMinute());
        return String.format(Locale.US, "%02d:%02d %s", (hour + 11) % 12 + 1,
                dt.getMinute(), hour >= 12 ? "PM" : "AM");
    }

    private static String formatUTC(int offsetSeconds) {
        int minutes = Math.abs(offsetSeconds) / 60;
        return String.format(Locale.US, "UTC%s%02d:%02d", offsetSeconds < 0 ? "−" : "+", minutes / 60, minutes % 60);
    }

    private static String relativeOffset(int seconds) {
        if (seconds == 0) return "与参考同一时差";
        int minutes = Math.abs(seconds) / 60;
        int hours = minutes / 60;
        int rem = minutes % 60;
        String magnitude = hours > 0 ? hours + "小时" : "";
        if (rem != 0) magnitude += rem + "分";
        return (seconds > 0 ? "快 " : "慢 ") + magnitude;
    }

    private void togglePin(String code) {
        if (pinned.contains(code)) pinned.remove(code);
        else pinned.add(code);
        storeSettings();
        renderList();
    }

    private void setReference(String code) {
        if (!AirportData.BY_CODE.containsKey(code)) return;
        referenceCode = code;
        storeSettings();
        renderList();
    }

    private void showReferencePicker() {
        ArrayList<AirportCity> choices = new ArrayList<>();
        for (String p : pinned) {
            AirportCity city = AirportData.BY_CODE.get(p);
            if (city != null) choices.add(city);
        }
        if (choices.isEmpty()) choices.add(AirportData.BY_CODE.get("EZE"));
        String[] labels = new String[choices.size()];
        for (int i = 0; i < choices.size(); i++) {
            AirportCity city = choices.get(i);
            labels[i] = city.chinese + "  ·  " + city.code;
        }
        new AlertDialog.Builder(this)
                .setTitle("选择参考城市（来自常用城市）")
                .setItems(labels, (dialog, which) -> setReference(choices.get(which).code))
                .setNegativeButton("取消", null)
                .show();
    }

    private void showDetail(AirportCity city) {
        Instant instant = Instant.ofEpochMilli(nowEpochMillis());
        ZonedDateTime here = instant.atZone(ZoneId.of(city.zoneId));
        ZonedDateTime base = instant.atZone(ZoneId.of(AirportData.BY_CODE.get(referenceCode).zoneId));
        String time = String.format(Locale.ROOT, "%04d-%02d-%02d %02d:%02d:%02d",
                here.getYear(), here.getMonthValue(), here.getDayOfMonth(),
                here.getHour(), here.getMinute(), here.getSecond());
        String info = city.english + " · " + city.country + "\n\n"
                + "当地时间：" + time + "\n"
                + "机场代码：" + city.airports + "\n"
                + "IANA 时区：" + city.zoneId + "\n"
                + "UTC 时差：" + formatUTC(here.getOffset().getTotalSeconds()) + "\n"
                + "与参考城市：" + relativeOffset(here.getOffset().getTotalSeconds() - base.getOffset().getTotalSeconds()) + "\n"
                + "夏令时：" + (here.getZone().getRules().isDaylightSavings(instant) ? "正在实行" : "未实行");
        new AlertDialog.Builder(this)
                .setTitle(city.chinese + "  " + city.code)
                .setMessage(info)
                .setPositiveButton("设为参考", (d, w) -> setReference(city.code))
                .setNeutralButton(pinned.contains(city.code) ? "取消收藏" : "加入收藏",
                        (d, w) -> togglePin(city.code))
                .setNegativeButton("关闭", null)
                .show();
    }

    private long nowEpochMillis() {
        return hasSynced ? calibratedEpochAtAnchor + SystemClock.elapsedRealtime() - calibratedElapsedAnchor
                         : System.currentTimeMillis();
    }

    private void synchronizeTime() {
        if (syncing) return;
        syncing = true;
        syncButton.setText("校准中");
        statusText.setText("连接网络时间 API · 如失败将保留设备时间");
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                long start = SystemClock.elapsedRealtime();
                URL url = new URL(SERVER);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5_000);
                connection.setReadTimeout(5_000);
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", "AirportWorldClock/1.0 (Android)");
                if (connection.getResponseCode() != 200) throw new IllegalStateException("HTTP " + connection.getResponseCode());
                String body;
                try (InputStream input = connection.getInputStream();
                     ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                    byte[] bytes = new byte[1024];
                    int len;
                    while ((len = input.read(bytes)) != -1) {
                        buffer.write(bytes, 0, len);
                        if (buffer.size() > 32768) throw new IllegalStateException("Response too large");
                    }
                    body = new String(buffer.toByteArray(), StandardCharsets.UTF_8);
                }
                JSONObject result = new JSONObject(body);
                String iso = result.optString("utc_datetime", "");
                if (iso.isEmpty()) iso = result.optString("datetime", "");
                long epochFromServer = !iso.isEmpty()
                        ? OffsetDateTime.parse(iso).toInstant().toEpochMilli()
                        : result.getLong("unixtime") * 1000L;
                long end = SystemClock.elapsedRealtime();
                long approxAtEnd = epochFromServer + (end - start) / 2L;
                long localClockAtEnd = System.currentTimeMillis();
                long delta = approxAtEnd - localClockAtEnd;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    calibratedEpochAtAnchor = approxAtEnd;
                    calibratedElapsedAnchor = end;
                    hasSynced = true;
                    syncing = false;
                    syncButton.setText("↻ 校时");
                    statusText.setText(String.format(Locale.ROOT,
                            "网络已校时 · 与设备相差 %+.1f 秒 · 仅前台刷新", delta / 1000.0));
                    handler.removeCallbacks(clockTicker);
                    if (foreground) handler.post(clockTicker);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    syncing = false;
                    syncButton.setText("↻ 校时");
                    statusText.setText(hasSynced ? "沿用本次网络校时结果 · 点击重试" :
                            "网络校时不可用 · 使用设备时间 · 点击重试");
                    updateClocks();
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        }, "worldclock-timesync").start();
    }

    private LinearLayout horizontal(int gravity) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(gravity);
        return layout;
    }

    private LinearLayout vertical() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        return layout;
    }

    private TextView label(String text, float sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setGravity(Gravity.CENTER_VERTICAL);
        view.setIncludeFontPadding(false);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView pill(String value, boolean selected) {
        TextView view = label(value, 12, selected ? MINT : WHITE, true);
        view.setGravity(Gravity.CENTER);
        view.setPadding(dp(11), 0, dp(11), 0);
        view.setBackground(roundBg(selected ? SELECTED : CARD, BORDER, 11));
        return view;
    }

    private GradientDrawable roundBg(int fill, int border, float radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(fill);
        drawable.setCornerRadius(dp(radius));
        drawable.setStroke(dp(1), border);
        return drawable;
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    private void addWithTop(LinearLayout parent, View child, int margin) {
        LinearLayout.LayoutParams params = lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(margin);
        parent.addView(child, params);
    }

    private int dp(float size) {
        return (int) (size * getResources().getDisplayMetrics().density + 0.5f);
    }
}
